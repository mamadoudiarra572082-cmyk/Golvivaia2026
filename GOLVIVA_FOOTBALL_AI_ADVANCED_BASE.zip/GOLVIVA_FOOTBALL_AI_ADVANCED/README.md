# GOLVIVA FOOTBALL AI ADVANCED

Application web Python/Streamlit pour analyser des cotes 1X2 et BTTS, conserver un historique local et interroger le serveur MCP Golviva.

## Endpoint API intégré
`https://api.golviva.com/mcp`

Le serveur MCP Golviva propose une authentification OAuth 2.1 pour les clients compatibles et une clé API personnelle Bearer pour les clients autonomes. Cette application accepte la clé Bearer. Elle ne réalise pas encore le parcours OAuth interactif du navigateur.

## Obtenir l'accès Golviva
1. Ouvrir https://golviva.com/mcp
2. Se connecter avec Google ou Apple.
3. Ouvrir la section d'utilisation / connexions et créer une clé API personnelle si l'application autonome le demande.
4. Copier la clé dans le champ sécurisé de l'application au lancement.
5. Ne jamais partager cette clé publiquement.

Golviva annonce un quota quotidien gratuit (vérifier le quota actuel sur le site).

## Installation sur ordinateur
Python 3.10+ recommandé.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Tests
```bash
python -m unittest discover -s tests
```

## Déploiement
Déployer sur un hébergeur compatible Streamlit/Python. Pour une utilisation durable, configurer `GOLVIVA_API_KEY` dans les secrets du serveur et modifier l'application pour lire cette variable, plutôt que de saisir la clé à chaque session.

## Limites honnêtes
- Les probabilités 1X2 et BTTS sont dérivées des cotes fournies et normalisées pour retirer proportionnellement la marge du bookmaker. Ce ne sont pas des prédictions indépendantes.
- Le serveur MCP est réellement configuré sur l'URL officielle. L'appel effectif nécessite une authentification valide.
- Le client MCP effectue `initialize`, `tools/list` et `tools/call` sur Streamable HTTP. Le protocole et la version peuvent évoluer ; adapter les en-têtes si le serveur exige une autre version.
- L'application ne déduit pas les scores exacts, les totaux de buts ou la mi-temps des seules cotes 1X2/BTTS.
- Les résultats de l'API sont présentés comme retournés par Golviva, sans prétendre qu'ils ont été vérifiés indépendamment.
