def _validate_odds(*values):
    for value in values:
        if value is None or float(value) <= 1.0:
            raise ValueError("Toutes les cotes décimales doivent être supérieures à 1.00.")

def _normalize(raw):
    total = sum(raw)
    return [x / total for x in raw], total - 1.0

def analyze_odds(odd1, oddx, odd2, odd_yes, odd_no):
    _validate_odds(odd1, oddx, odd2, odd_yes, odd_no)
    raw_1x2 = [1/odd1, 1/oddx, 1/odd2]
    p, margin_1x2 = _normalize(raw_1x2)
    raw_btts = [1/odd_yes, 1/odd_no]
    b, margin_btts = _normalize(raw_btts)
    return {
        "odd1": float(odd1), "oddx": float(oddx), "odd2": float(odd2),
        "odd_yes": float(odd_yes), "odd_no": float(odd_no),
        "p1": p[0], "px": p[1], "p2": p[2],
        "margin_1x2": margin_1x2,
        "btts_yes": b[0], "btts_no": b[1], "margin_btts": margin_btts,
        "ev1": p[0]*odd1-1, "evx": p[1]*oddx-1, "ev2": p[2]*odd2-1,
        "ev_yes": b[0]*odd_yes-1, "ev_no": b[1]*odd_no-1,
    }

def build_prediction_report(home, away, odds):
    return {
        "teams": [home, away],
        "market_probabilities": {"home": odds["p1"], "draw": odds["px"], "away": odds["p2"]},
        "btts_probabilities": {"yes": odds["btts_yes"], "no": odds["btts_no"]},
        "note": "Probabilités de marché corrigées de la marge, pas prédictions indépendantes.",
        "extra_markets": "Données insuffisantes sans statistiques de buts fiables."
    }
