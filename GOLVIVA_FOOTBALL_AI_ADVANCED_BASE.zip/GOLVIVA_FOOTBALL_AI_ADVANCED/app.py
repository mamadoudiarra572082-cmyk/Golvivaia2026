import streamlit as st
import pandas as pd
from datetime import datetime, timezone
from analyzer import analyze_odds, build_prediction_report
from golviva_client import GolvivaMCPClient, GolvivaError
from storage import init_db, save_analysis, load_history

st.set_page_config(page_title="Golviva Football AI Advanced", page_icon="⚽", layout="wide")
init_db()

st.markdown("""
<style>
.block-container {padding-top: 1.5rem; max-width: 1200px;}
.hero {padding: 1.4rem 1.6rem; border-radius: 18px; background: linear-gradient(120deg,#10251e,#173d30); color:#fff; margin-bottom:1rem;}
.hero h1 {margin:0; font-size:2rem;} .muted {color:#a8b8b0;}
div[data-testid="stMetric"] {background:#f5f8f6; padding:12px; border-radius:12px;}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>⚽ GOLVIVA FOOTBALL AI</h1><p class="muted">ADVANCED · Analyse indépendante des cotes + données Golviva MCP</p></div>', unsafe_allow_html=True)

with st.sidebar:
    st.header("Configuration Golviva")
    st.caption("Serveur MCP officiel")
    st.code("https://api.golviva.com/mcp")
    st.markdown("[Ouvrir Golviva et gérer l'accès](https://golviva.com/mcp)")
    api_key = st.text_input("Clé API personnelle (facultative ici)", type="password",
                            help="Crée une clé sur Golviva si l'application autonome te la demande. Elle n'est pas enregistrée dans l'historique.")
    st.caption("La clé reste en mémoire pendant cette session. Pour un déploiement, configure-la côté serveur dans les secrets.")
    st.divider()
    page = st.radio("Navigation", ["Nouvelle analyse", "Historique", "À propos"])

if page == "Nouvelle analyse":
    st.subheader("Saisir un match")
    with st.form("match_form"):
        c1, c2 = st.columns(2)
        with c1:
            home = st.text_input("Équipe 1 / domicile", placeholder="Ex. Arsenal")
            odd1 = st.number_input("Cote victoire équipe 1", min_value=1.01, value=2.10, step=0.01, format="%.2f")
            oddx = st.number_input("Cote match nul", min_value=1.01, value=3.40, step=0.01, format="%.2f")
        with c2:
            away = st.text_input("Équipe 2 / extérieur", placeholder="Ex. Chelsea")
            odd2 = st.number_input("Cote victoire équipe 2", min_value=1.01, value=3.60, step=0.01, format="%.2f")
            st.write("")
            st.write("")
        st.markdown("**Les deux équipes marquent (BTTS)**")
        b1, b2 = st.columns(2)
        with b1:
            yes = st.number_input("BTTS OUI", min_value=1.01, value=1.75, step=0.01, format="%.2f")
        with b2:
            no = st.number_input("BTTS NON", min_value=1.01, value=2.00, step=0.01, format="%.2f")
        submitted = st.form_submit_button("🔎 ANALYSER LE MATCH", use_container_width=True)

    if submitted:
        if not home.strip() or not away.strip() or home.strip().lower() == away.strip().lower():
            st.error("Saisis deux noms d'équipes différents.")
        else:
            odds = analyze_odds(odd1, oddx, odd2, yes, no)
            st.session_state["last_analysis"] = {"home": home.strip(), "away": away.strip(), "odds": odds}
            st.success("Analyse des cotes terminée.")
            st.info("Recherche des données Golviva en cours…")
            try:
                client = GolvivaMCPClient(api_key=api_key.strip() or None)
                tools = client.list_tools()
                tool_names = [t.get("name", "") for t in tools]
                st.session_state["golviva_tools"] = tool_names
                # Golviva's prediction tool is queried by team name. We do not assume undocumented arguments.
                if "get_match_prediction" in tool_names:
                    result = client.call_tool("get_match_prediction", {"team": home.strip()})
                    st.session_state["golviva_result"] = result
                    st.session_state["golviva_status"] = "Données Golviva récupérées."
                elif "get_predictions" in tool_names:
                    result = client.call_tool("get_predictions", {})
                    st.session_state["golviva_result"] = result
                    st.session_state["golviva_status"] = "Pronostics du jour récupérés. Vérifier la correspondance du match."
                else:
                    st.session_state["golviva_result"] = None
                    st.session_state["golviva_status"] = "Connexion établie, mais aucun outil de prédiction reconnu."
            except Exception as e:
                st.session_state["golviva_result"] = None
                st.session_state["golviva_status"] = str(e)
            report = build_prediction_report(home.strip(), away.strip(), odds)
            save_analysis(home.strip(), away.strip(), odds, report)
            st.session_state["report"] = report

    if "report" in st.session_state:
        data = st.session_state["last_analysis"]
        odds = data["odds"]
        st.divider()
        st.subheader(f"{data['home']} vs {data['away']}")
        m1, m2, m3 = st.columns(3)
        m1.metric(f"1 · {data['home']}", f"{odds['p1']:.1%}")
        m2.metric("X · Match nul", f"{odds['px']:.1%}")
        m3.metric(f"2 · {data['away']}", f"{odds['p2']:.1%}")
        st.markdown("### Analyse des cotes")
        st.write(f"Marge bookmaker estimée (marché 1X2) : **{odds['margin_1x2']:.2%}**")
        st.write(f"BTTS OUI : **{odds['btts_yes']:.1%}** · BTTS NON : **{odds['btts_no']:.1%}** · Marge BTTS : **{odds['margin_btts']:.2%}**")
        df = pd.DataFrame([
            {"Marché":"1X2", "Sélection":data["home"], "Cote":odds["odd1"], "Probabilité sans marge":odds["p1"], "EV":odds["ev1"]},
            {"Marché":"1X2", "Sélection":"Match nul", "Cote":odds["oddx"], "Probabilité sans marge":odds["px"], "EV":odds["evx"]},
            {"Marché":"1X2", "Sélection":data["away"], "Cote":odds["odd2"], "Probabilité sans marge":odds["p2"], "EV":odds["ev2"]},
            {"Marché":"BTTS", "Sélection":"OUI", "Cote":odds["odd_yes"], "Probabilité sans marge":odds["btts_yes"], "EV":odds["ev_yes"]},
            {"Marché":"BTTS", "Sélection":"NON", "Cote":odds["odd_no"], "Probabilité sans marge":odds["btts_no"], "EV":odds["ev_no"]},
        ])
        st.dataframe(df.style.format({"Cote":"{:.2f}", "Probabilité sans marge":"{:.1%}", "EV":"{:+.1%}"}), use_container_width=True)
        values = [("1", odds["ev1"]), ("X", odds["evx"]), ("2", odds["ev2"]), ("BTTS OUI", odds["ev_yes"]), ("BTTS NON", odds["ev_no"])]
        positive = [(k,v) for k,v in values if v > 0]
        if positive:
            st.success("Valeurs théoriquement positives : " + ", ".join(f"{k} ({v:+.1%})" for k,v in positive))
        else:
            st.warning("Aucune espérance mathématique positive détectée avec les probabilités dérivées des cotes.")
        st.markdown("### Prédictions supplémentaires")
        st.warning("Les scores exacts, les buts totaux et la mi-temps ne sont pas déduits des seules cotes 1X2/BTTS. Ils ne seront affichés que si des données statistiques suffisantes sont récupérées.")
        st.markdown("### Connexion Golviva")
        status = st.session_state.get("golviva_status", "Pas encore interrogé.")
        st.write(status)
        if st.session_state.get("golviva_result") is not None:
            st.json(st.session_state["golviva_result"])
        elif "401" in status or "403" in status or "auth" in status.lower() or "clé" in status.lower():
            st.info("L'accès autonome nécessite une authentification. Connecte-toi sur Golviva, puis crée une clé API personnelle dans la section Utilisation et connexions. Ajoute-la dans le champ de la barre latérale et relance l'analyse.")
        st.caption("Les probabilités issues des cotes décrivent le marché après retrait proportionnel de la marge ; elles ne constituent pas une prédiction indépendante du résultat.")

elif page == "Historique":
    st.subheader("Historique des analyses")
    hist = load_history()
    if hist.empty:
        st.info("Aucune analyse enregistrée pour le moment.")
    else:
        st.dataframe(hist, use_container_width=True, hide_index=True)

else:
    st.subheader("À propos du projet")
    st.markdown("""
**GOLVIVA FOOTBALL AI ADVANCED** sépare trois choses :
- **Marché** : probabilités implicites normalisées à partir des cotes saisies.
- **Golviva** : données récupérées auprès du serveur MCP officiel, lorsqu'une authentification est disponible.
- **Estimation indépendante** : elle ne sera ajoutée que lorsque des statistiques réelles et suffisantes seront disponibles.

Serveur MCP : `https://api.golviva.com/mcp`

L'application ne garantit aucun gain et ne présente pas les paris comme une source de revenu.
""")
