"""Client MCP Streamable HTTP minimal pour le serveur Golviva.
Endpoint officiel : https://api.golviva.com/mcp
L'authentification OAuth interactive n'est pas implémentée ici ; le client accepte une clé personnelle Bearer.
"""
import json
import requests

MCP_URL = "https://api.golviva.com/mcp"
PROTOCOL_VERSION = "2025-03-26"

class GolvivaError(RuntimeError):
    pass

class GolvivaMCPClient:
    def __init__(self, api_key=None, timeout=30):
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()
        self.session_id = None
        self.request_id = 0
        self.headers = {
            "Accept": "application/json, text/event-stream",
            "Content-Type": "application/json",
            "MCP-Protocol-Version": PROTOCOL_VERSION,
        }
        if api_key:
            self.headers["Authorization"] = f"Bearer {api_key}"

    def _next_id(self):
        self.request_id += 1
        return self.request_id

    def _decode_response(self, response):
        if response.status_code in (401, 403):
            raise GolvivaError("Authentification refusée (HTTP %s). Connecte-toi à Golviva et crée une clé API personnelle, puis réessaie." % response.status_code)
        if not response.ok:
            raise GolvivaError(f"Erreur HTTP {response.status_code}: {response.text[:500]}")
        sid = response.headers.get("Mcp-Session-Id")
        if sid:
            self.session_id = sid
        content_type = response.headers.get("Content-Type", "")
        body = response.text.strip()
        if "text/event-stream" in content_type:
            messages = []
            for line in body.splitlines():
                if line.startswith("data:"):
                    payload = line[5:].strip()
                    if payload and payload != "[DONE]":
                        try:
                            messages.append(json.loads(payload))
                        except json.JSONDecodeError:
                            pass
            return messages[-1] if messages else {}
        if body:
            try:
                return response.json()
            except ValueError:
                raise GolvivaError("Réponse MCP non reconnue.")
        return {}

    def _post(self, payload):
        headers = dict(self.headers)
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        response = self.session.post(MCP_URL, headers=headers, json=payload, timeout=self.timeout)
        return self._decode_response(response)

    def initialize(self):
        payload = {
            "jsonrpc": "2.0", "id": self._next_id(), "method": "initialize",
            "params": {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "Golviva Football AI Advanced", "version": "1.0.0"}
            }
        }
        result = self._post(payload)
        if "error" in result:
            raise GolvivaError(str(result["error"]))
        self._post({"jsonrpc":"2.0", "method":"notifications/initialized"})
        return result.get("result", {})

    def list_tools(self):
        self.initialize()
        result = self._post({"jsonrpc":"2.0", "id":self._next_id(), "method":"tools/list", "params":{}})
        if "error" in result:
            raise GolvivaError(str(result["error"]))
        return result.get("result", {}).get("tools", [])

    def call_tool(self, name, arguments):
        result = self._post({
            "jsonrpc":"2.0", "id":self._next_id(), "method":"tools/call",
            "params":{"name":name, "arguments":arguments}
        })
        if "error" in result:
            raise GolvivaError(str(result["error"]))
        return result.get("result", result)
