import sqlite3, json
from pathlib import Path
import pandas as pd

DB_PATH = Path(__file__).parent / "golviva_history.db"

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            home TEXT NOT NULL,
            away TEXT NOT NULL,
            odds_json TEXT NOT NULL,
            report_json TEXT NOT NULL
        )""")

def save_analysis(home, away, odds, report):
    from datetime import datetime, timezone
    with sqlite3.connect(DB_PATH) as con:
        con.execute("INSERT INTO analyses(created_at,home,away,odds_json,report_json) VALUES(?,?,?,?,?)",
                    (datetime.now(timezone.utc).isoformat(), home, away,
                     json.dumps(odds), json.dumps(report)))

def load_history():
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute("SELECT created_at,home,away,odds_json FROM analyses ORDER BY id DESC").fetchall()
    if not rows:
        return pd.DataFrame()
    data = []
    for created, home, away, raw in rows:
        odds = json.loads(raw)
        data.append({"Date UTC":created, "Équipe 1":home, "Équipe 2":away,
                     "P(1)":f"{odds['p1']:.1%}", "P(X)":f"{odds['px']:.1%}",
                     "P(2)":f"{odds['p2']:.1%}", "BTTS OUI":f"{odds['btts_yes']:.1%}"})
    return pd.DataFrame(data)
