import unittest
from analyzer import analyze_odds

class TestOdds(unittest.TestCase):
    def test_probabilities_sum_to_one(self):
        x = analyze_odds(2.1, 3.4, 3.6, 1.75, 2.0)
        self.assertAlmostEqual(x["p1"] + x["px"] + x["p2"], 1.0)
        self.assertAlmostEqual(x["btts_yes"] + x["btts_no"], 1.0)

    def test_invalid_odds(self):
        with self.assertRaises(ValueError):
            analyze_odds(1.0, 3.4, 3.6, 1.75, 2.0)

if __name__ == "__main__":
    unittest.main()
